class FilmItem extends HTMLElement {
  constructor() {
    super();
    this.shadowDOM = this.attachShadow({ mode: 'open' });
  }

  set film(film) {
    this._film = film;
    this.render();
  }

  async fetchFilmData() {
    try {
      const response = await fetch(
        `https://api.themoviedb.org/3/movie/${this._film.id}?api_key=de8123c6b3ccaaf3d625b253841913d6`
      );

      if (!response.ok) {
        throw new Error('Failed to fetch film data');
      }

      const filmData = await response.json();
      return filmData;
    } catch (error) {
      console.error('Error fetching film data:', error);
      return null;
    }
  }

  async render() {
    const filmData = await this.fetchFilmData();

    if (!filmData) {
      // Handle the error here
      this.shadowDOM.innerHTML = `<p>Error fetching film data</p>`;
      return;
    }

    this.shadowDOM.innerHTML = `
    <style>
    .film-list {
      display: grid;
      grid-template-columns: repeat(3, 1fr); /* Membuat 3 kolom dengan lebar yang sama */
      gap: 20px; /* Jarak antara elemen */
    }
  
    .film-item {
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      border-radius: 10px;
      overflow: hidden;
      background-color: #fff;
    }
  
    .poster-film {
      width: 100%;
      height: auto;
      object-fit: cover;
    }
  
    .film-info {
      padding: 16px;
    }
  
    h2 {
      font-size: 1.5rem;
      margin-bottom: 8px;
    }
  
    p {
      font-size: 1rem;
      line-height: 1.2;
    }
  </style>  
  

      <img class="poster-film" src="https://image.tmdb.org/t/p/w500${filmData.poster_path}" alt="poster">
      <div class="film-info">
        <h2>${filmData.original_title}</h2>
        <p>${filmData.overview}</p>
        <p>${filmData.popularity}</p>
      </div>
    `;
  }
}

customElements.define('film-item', FilmItem);
