class DataSource {
  static searchFilm(keyword) {
    return fetch(`https://api.themoviedb.org/3/search/movie?api_key=de8123c6b3ccaaf3d625b253841913d6&query=${keyword}`)
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        return response.json();
      })
      .then(responseJson => {
        if (responseJson.results) {
          return Promise.resolve(responseJson.results);
        } else {
          return Promise.reject(`${keyword} is not found`);
        }
      })
      .catch(error => {
        console.error(error);
        return Promise.reject('An error occurred while fetching data');
      });
  }
}

export default DataSource;
